<?php

// route
require __DIR__ . '/Controllers/student.php';


